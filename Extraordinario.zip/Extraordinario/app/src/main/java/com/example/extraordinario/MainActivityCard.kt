package com.example.extraordinario

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivityCard : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var logoutButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_card)

        recyclerView = findViewById(R.id.recycler_view)
        logoutButton = findViewById(R.id.logout_button)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = MyAdapter(getDummyData())

        logoutButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun getDummyData(): List<MyData> {
        return listOf(
            MyData("Futbol", "El fútbol se define en primer lugar como un juego que incluye dos contrincantes y un árbitro con la capacidad de imponer justicia imparcial. "),
            MyData("Beisbol", "El béisbol es un deporte competitivo de habilidad que se juega con una bola dura y un bate entre dos equipos de nueve jugadores cada uno.\n"),
            MyData("Basquet", "El basquetbol, también conocido como baloncesto o básquet, es un deporte de competición por equipos.")
        )
    }
}